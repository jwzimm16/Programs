#include <fstream>
#include <iostream>
#include <string>
#include <vector>
using namespace std;

struct User
{
	string m_username;

	void SetUserName(const string& name)
	{
		m_username = name;
	}

	User(const string& name)
	{
		SetUserName(name);
	}

	string GetUsername()
	{
		return m_username;
	}
};

struct Post
{
	string m_contents;
	int m_authorId;

	Post()
	{

	}

	string GetContects()
	{
		return m_contents;
	}

	int GetAuthorID()
	{
		return m_authorId;
	}

	Post(const string& contents, int authorId)
	{
		SetContents(contents);
		SetAuthorID(authorId);
	}

	void SetContents(const string& contents)
	{
		m_contents = contents;
	}

	void SetAuthorID(int id)
	{
		m_authorId = id;
	}
};

class Blog
{
private:
	vector<User> m_userList;
	vector<Post> m_postList;
	int m_currentUser;

	void LoadFiles()
	{
		ifstream userInput("users.txt");

		string name;
		while (userInput >> name)
		{
			User newUser(name);
			m_userList.push_back(newUser);
		}

		userInput.close();

		ifstream postInput("posts.txt");

		string buffer;
		string post;
		int authorId;

		while (postInput >> buffer)
		{
			postInput >> authorId;
			post = "";
			buffer = "";

			postInput.ignore();
			while (buffer != "DONE")
			{
				if (buffer != "")
				{
					post += buffer + "\n";
				}
				getline(postInput, buffer);
			}

			Post newPost(post, authorId);
			m_postList.push_back(newPost);
		}

		postInput.close();
	}

	void SaveFiles()
	{
		string name;

		for (int i = 0; i < m_userList.size(); i++)
		{
			ofstream userOutput("users.txt");

			User userName(name);
			userOutput << userName.GetUsername() << "\n";

			userOutput.close();
		}
	}

	void MainMenu()
	{
		while (true)
		{
			int choice = Menu::ShowMenuWithPrompt({ "Register", "Login", "Exit" });

			if (choice == 1)
			{
				Register();
			}
			else if (choice == 2)
			{

			}
			else if (choice == 3)
			{
				break;
			}
		}
	}

	void Register()
	{
		cout << "Enter new username: ";
		string name;
		cin >> name;

		User newUser(name);
		m_userList.push_back(newUser);
		m_currentUser = m_userList.size() - 1;

		SaveFiles();
	}

public:
	void Run()
	{
		LoadFiles();
		MainMenu();
	}
};
