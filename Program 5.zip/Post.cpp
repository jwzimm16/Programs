#include <string>
using namespace std;

#include "Post.hpp"

Post::Post()
{

}

string Post::GetContents()
{
    return m_contents;
}

int Post::GetAuthorID()
{
    return m_authorId;
}

Post::Post(const string& contents, int authorId)
{
    SetContents(contents);
    SetAuthorID(authorId);
}

void Post::SetContents(const string& contents)
{
    m_contents = contents;
}

void Post::SetAuthorID(int id)
{
    m_authorId = id;
}
