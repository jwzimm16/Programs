#include <string>
#include <fstream>
#include <iostream>
#include <stdlib.h>
using namespace std;

#include "Blog.hpp"

void Blog::LoadFiles()
{
    ifstream userInput("users.txt");

    string name;
    while (userInput >> name)
    {
        User newUser(name);
        m_userList.push_back(newUser);
    }

    userInput.close();

    ifstream postInput("posts.txt");

    string buffer;
    string post;
    int authorId;

    while (postInput >> buffer)
    {
        postInput >> authorId;
        post = "";
        buffer = "";

        postInput.ignore();
        while (buffer != "DONE")
        {
            if (buffer != "")
            {
                post += buffer + "\n";
            }
            getline(postInput, buffer);
        }

        Post newPost(post, authorId);
        m_postList.push_back(newPost);
    }

    postInput.close();
}

int Blog::GetUserInput(int minimum, int maximum)
{
    int choice;
    bool done = false;
    while ( !done )
    {
        cout << endl << ">> ";
        cin >> choice;

        if ( choice < minimum || choice > maximum)
        {
            cout << endl << "Incorrect choice, try again." << endl;
        }
        else
        {
            done = true;
        }
    }

    return choice;
}

void Blog::MainMenu()
{
    bool done = false;

    while ( !done )
    {
        cout << "1. Register" << endl;
        cout << "2. Login" << endl;
        cout << "3. Exit" << endl;

        int choice = Blog::GetUserInput(1, 3);

        if (choice == 1)
        {
            Register();
            UserMainMenu();
        }
        else if (choice == 2)
        {
            Login();
            UserMainMenu();
        }
        else if (choice == 3)
        {
            done = true;
        }
    }
}

void Blog::Wall()
{
    int currentPost = 0;
    int size = m_postList.size();
    bool done = false;


    while ( !done )
    {
        cout << m_userList[m_postList[currentPost].GetAuthorID()].GetUsername() << endl << endl;
        cout << m_postList[currentPost].GetContents() << endl << endl;
        cout << "(B)ack, (F)orward or (E)xit? ";
        char choice;
        cin >> choice;

        if (choice == 'b' || choice == 'B')
        {
            if (currentPost == 0)
            {
                ClearScreen();
                cout << endl << "Already at beginning of posts." << endl;
            }
            else
            {
                currentPost--;
                ClearScreen();
            }
        }
        else if (choice == 'f' || choice == 'F')
        {
            if (currentPost + 1 > size)
            {
                ClearScreen();
                cout << endl << "At end of posts." << endl;
            }
            else
            {
                currentPost++;
                ClearScreen();
            }
        }
        else if (choice == 'e' || choice == 'E')
        {
            done = true;
        }
    }
}

void Blog::AddPost()
{
    SaveFiles();
}

void Blog::UserMainMenu()
{
    bool done = false;

    while ( !done )
    {
        cout << "1. Add Post" << endl;
        cout << "2. View Blog Wall" << endl;
        cout << "3. Search" << endl;
        cout << "4. Log Out" << endl;

        int choice = Blog::GetUserInput(1, 4);

        if (choice == 1)
        {
            // AddPost();
        }
        else if (choice == 2)
        {
            Wall();
        }
        else if (choice == 3)
        {
            // Search();
        }
        else
        {
            done = true;
        }
    }

    cout << endl;
}

void Blog::Register()
{
	cout << endl << "Enter new username: ";
	string name;
	cin >> name;

	User newUser(name);
	m_userList.push_back(newUser);
	m_currentUser = m_userList.size() - 1;

	SaveFiles();
	cout << endl;
}

void Blog::Login()
{
    vector<string> usernameList;
    int choice;

    cout << endl;

    int size = m_userList.size();
    for (int i = 0; i < size; i++)
    {
        usernameList.push_back(m_userList[i].GetUsername());
    }

    size = usernameList.size();
    for (int i = 0; i < size; i++)
    {
        cout << i << ". " << usernameList[i] << endl;
    }

    while (true)
    {
        cout << endl << "Select user: ";
        cin >> choice;

        if (choice < size)
        {
            break;
        }
        else
        {
            cout << "Incorrect choice, try again: ";
        }
    }

    m_currentUser = choice;
    cout << endl;
}

void Blog::SaveFiles()
{
    ofstream outUsers("users.txt");

    int size = m_userList.size();
    for (int i = 0; i < size; i++)
    {
        outUsers << m_userList[i].GetUsername() << endl;
    }

    outUsers.close();

    ofstream outPosts("posts.txt");

    size = m_postList.size();
    for (int i = 0; i < size; i++)
    {
        outPosts << "AUTHOR_ID " << m_postList[i].GetAuthorID() << endl;
        outPosts << m_postList[i].GetContents() << endl;
        outPosts << "DONE" << endl;
    }

    outPosts.close();
}

void Blog::ClearScreen()
{
    #if defined(WIN32) || defined(_WIN32) || defined(__WIN32) && !defined(__CYGWIN__)
        system( "cls" );
    #else
        system( "clear" );
    #endif
}

void Blog::Run()
{
    LoadFiles();
    MainMenu();
}
