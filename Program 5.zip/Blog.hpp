#ifndef _BLOG
#define _BLOG

#include <string>
#include <vector>
using namespace std;

#include "User.hpp"
#include "Post.hpp"

class Blog
{
private:
	vector<User> m_userList;
	vector<Post> m_postList;
	int m_currentUser;
	int GetUserInput(int min, int max);
	void LoadFiles();
	void SaveFiles();
	void MainMenu();
	void Register();
	void Login();
	void UserMainMenu();
	void AddPost();
	void Wall();
	void Search();
	void ClearScreen();

public:
	void Run();
};

#endif
