#include "Blog.hpp"

int main()
{
    Blog blog;
    blog.Run();

	return 0;
}
