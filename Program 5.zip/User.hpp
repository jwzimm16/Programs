#ifndef _USER
#define _USER

#include <string>
using namespace std;

class User
{
private:
    string m_username;

public:
    User(const string& name);
    void SetUsername(const string& name);
    string GetUsername();
};

#endif
