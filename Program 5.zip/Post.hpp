#ifndef _POST
#define _POST

#include <string>
using namespace std;

class Post
{
private:
    string m_contents;
    int m_authorId;

public:
    Post();
    string GetContents();
	int GetAuthorID();
	Post(const string& contents, int authorId);
	void SetContents(const string& contents);
	void SetAuthorID(int id);
};

#endif
