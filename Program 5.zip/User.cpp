#include <string>
using namespace std;

#include "User.hpp"

void User::SetUsername(const string& name)
{
    m_username = name;
}

User::User(const string& name)
{
    SetUsername(name);
}

string User::GetUsername()
{
    return m_username;
}
