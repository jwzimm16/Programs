#ifndef LIBRARY_HPP_INCLUDED
#define LIBRARY_HPP_INCLUDED

#include <iostream>
#include <ostream>
#include <fstream>
#include <string>

using namespace std;

struct Book
{
    string title;
    string author;
    int id;

    void Setup(const string& newTitle, const string& newAuthor, int newid)
    {
        title = newTitle;
        author = newAuthor;
        id = newid;
    }

    string Formatted()
    {
        string formatted;
        formatted = title + "\t" + author;
        return formatted;
    }
};

struct Library
{
    Book bookList[80];
    int listSize;
    int bookCount;
    string title;
    string author;
    int id;

    void InitLibrary()
    {
        ifstream library("library.txt");

        listSize = 80;
        bookCount = 0;

        string buffer, first, middle, last;
        library >> buffer >> buffer >> buffer;

		while (library >> id >> title >> first >> middle >> last)
        {
            author = first + " " + middle + " " + last;
            bookList[bookCount].Setup(title, author, id);
			bookCount++;
        }

        library.close();
    }

    void Run()
    {
        while(true)
        {
            int choice = MainMenu();
            if (choice == 1)
            {
                RunPublic();
            }
            else if (choice == 2)
            {
                RunAdmin();
            }
            else
            {
                break;
            }
        }
    }

    int GetValidInput(int min, int max)
    {
        int choice;
        while (true)
        {
            cout << endl << ">> ";
            cin >> choice;

            if (choice >= min || choice <= max)
            {
                break;
            }
            else
            {
                cout << endl << "Invalid value, try again." << endl;
            }
        }

        return choice;
    }

    int MainMenu()
    {
        cout << "1. Public Access" << endl;
        cout << "2. Admin Access" << endl;
        cout << "3. Exit" << endl;
        int choice = GetValidInput(1,3);
        cout << endl;
        return choice;
    }

    int PublicMenu()
    {
        cout << "1. Search by title" << endl;
        cout << "2. Search by author" << endl;
        int choice = GetValidInput(1,2);
        cout << endl;
        return choice;
    }

    int AdminMenu()
    {
        cout << "1. Update book" << endl;
        cout << "2. Add book" << endl;
        cout << "3. Export database" << endl;
        int choice = GetValidInput(1,3);
		cout << endl;
        return choice;
    }

    void RunPublic()
    {
        int choice = PublicMenu();
        if (choice == 1)
        {
            SearchByTitle();
        }
        else if (choice == 2)
        {
            SearchByAuthor();
        }
    }

    void RunAdmin()
    {
        int choice = AdminMenu();
        if (choice == 1)
        {
            UpdateBook();
        }
        else if (choice == 2)
        {
            AddBook();
        }
        else if (choice == 3)
        {
            SaveLibrary();
        }
    }

    void SearchByTitle()
    {
        string text, search;
        cout << "Enter a title to search for >> ";
        cin >> search;
        cout << endl;
        for (int i = 0; i < bookCount; i++)
        {
            text = bookList[i].title;
            size_t found = text.find(search);
            if (found != string::npos)
            {
                cout << bookList[i].id << "\t" << bookList[i].Formatted() << endl;
            }
        }

        cout << endl;
    }

    void SearchByAuthor()
    {
        string text, search;
        string first, middle, last;
        cout << "Enter an author to search for >> ";
        cin >> first >> middle >> last;
        search = first + " " + middle + " " + last;
        cout << endl;
        for (int i = 0; i < bookCount; i++)
        {
            text = bookList[i].author;
            size_t found = text.find(search);
            if (found != string::npos)
            {
                cout << bookList[i].id << "\t" << bookList[i].Formatted() << endl;
            }
        }

        cout << endl;
    }

    void UpdateBook(int index)
    {
        string first, middle, last;
        cout << "New Title: ";
        cin >> bookList[index].title;
        cout << "New First, Middle and Last Name: ";
        cin >> first >> middle >> last;
        bookList[index].author = first + " " + middle + " " + last;
        cout << endl;
    }

    void UpdateBook()
    {
        int index = SelectBook();
        UpdateBook(index);
    }

    int SelectBook()
    {
        int increment = 20;
        int pages = bookCount / increment;

        while(true)
        {
            for (int p = 0; p <= pages; p++)
            {
                int first = p*increment;
                int last = p*increment+increment;

                for (int i = first; i < last; i++)
                {
                    cout << i+1 << ". " << bookList[i].id << "\t";
                    int size = bookList[i].title.size();
                    if (size < 16)
                    {
                        cout << bookList[i].title << "\t\t";
                    }
                    else
                    {
                        cout << bookList[i].title << "\t";
                    }
                    cout << bookList[i].author << endl;
                }

                int index;
                cout << endl << "Enter any other number to go to next page >> ";
                cin >> index;
				cout << endl;

                if(index-1 >= first && index-1 < last)
                {
                    return index-1;
                }
            }
        }
    }

    void AddBook()
    {
        if (bookCount >= listSize)
        {
            cout << "Book list is full." << endl << endl;
        }
        else
        {
            UpdateBook(bookCount);
            bookList[bookCount].id = bookList[bookCount-1].id + 1;
            bookCount++;
        }
    }

    void SaveLibrary()
    {
        ofstream output("newlibrary.txt");

        output << "ID\tTITLE\t\t\tAUTHOR" << endl;

        for (int i = 0; i < bookCount; i++)
        {
            output << bookList[i].id << "\t";
            int size = bookList[i].title.size();
            if (size < 16)
            {
                output << bookList[i].title << "\t\t";
            }
            else
            {
                output << bookList[i].title << "\t";
            }
            output << bookList[i].author << "\n";
        }

        output.close();
    }
};

#endif // LIBRARY_HPP_INCLUDED
