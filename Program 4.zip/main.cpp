#include "Library.hpp"

int main()
{
    Library library;
    library.InitLibrary();
    library.Run();

    return 0;
}
